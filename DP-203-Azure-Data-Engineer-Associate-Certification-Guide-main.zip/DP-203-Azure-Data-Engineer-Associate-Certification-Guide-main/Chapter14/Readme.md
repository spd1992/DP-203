# Chapter 14

## Overview
In this chapter, we will see code examples for: 

* Spark Delta example
* Writing UDFs in Synapse SQL pool
* Identifying Shuffles in a SQL query plan
* Identifying Shuffles in a Spark query plan
* Indexing in Synapse Spark pool using Hyperspace


## Steps:
1. Follow the instructions in each file.