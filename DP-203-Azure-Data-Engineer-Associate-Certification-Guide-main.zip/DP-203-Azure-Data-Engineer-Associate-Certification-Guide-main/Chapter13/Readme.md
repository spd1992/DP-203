# Chapter 13

## Overview
In this chapter, we will see code examples for: 

* Creating statistics for Synapse dedicated pools
* Creating statistics for Synapse serverless pools
* Querying the system tables in Synapse dedicated pools


## Steps:
1. Follow the instructions in each file.

