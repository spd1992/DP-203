# Chapter 8

## Overview
In this chapter, we will see code examples for: 

* Spark transformations
* T-SQL trasformations
* Shredding JSON using Spark
* Shredding JSON using Synapse SQL
* Encoding and Decoding using Spark


## Steps:
1. Follow the instructions in each file.

