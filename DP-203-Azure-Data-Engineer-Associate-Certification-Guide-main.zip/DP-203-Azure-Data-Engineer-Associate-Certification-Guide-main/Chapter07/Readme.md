# Chapter 7

## Overview
In this chapter, we will see code examples for: 

* Implementing a Star schema
* Reading and writing Parquet files using Synapse SQL Serverless
* Reading and writing Parquet files using Spark

## Steps:
1. Follow the instructions in each file.

