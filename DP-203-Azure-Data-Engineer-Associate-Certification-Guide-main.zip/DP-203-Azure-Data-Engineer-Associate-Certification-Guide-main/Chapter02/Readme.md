# Chapter 2

## Overview
In this chapter, we will see how to create: 

* Synapse SQL Distribution Strategy
* Dedicated SQL pool example with pruning
* Spark example with pruning


## Steps:
1. Create an Azure Synapse workspace and launch it.
2. Open a SQL Editor and start copy pasting the lines from the corresponding example files in this directory.
3. Or you could just import the file into your synapse workspace.







