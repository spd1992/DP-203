# Chapter 12

## Overview
In this chapter, we will see code examples for: 

* Always Encrypted in Azure SQL
* Data Masking in Synapse SQL
* Row level security in Synapse SQL
* Column level security in Synapse SQL
* Loading dataframe with sensitive information in Spark


## Steps:
1. Follow the instructions in each file.
