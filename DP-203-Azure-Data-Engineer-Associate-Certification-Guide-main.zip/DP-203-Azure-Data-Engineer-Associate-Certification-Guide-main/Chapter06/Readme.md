# Chapter 6

## Overview
In this chapter, we will see code examples for: 

* Partition switching using Synapse SQL
* External tables using Synapse SQL


## Steps:
1. Follow the instructions in each fileS.

