# Chapter 4

## Overview
In this chapter, we will see code examples for: 

* Designing a solution for temporal data
* Designing a dimensional hierarchy
* Loading tables using watermark technique


## Steps:
1. Follow the instructions in each file as they use different services.





