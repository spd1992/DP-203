# Chapter 10

## Overview
In this chapter, we will see code examples for: 

* Sample event generation script for EventHub
* Spark Structured streaming
* Creating windowed aggregates
* Transformations using Streaming Analytics


## Steps:
1. Follow the instructions in each file.
