# Chapter 9

## Overview
In this chapter, we will see code examples for: 

* Batch Transformation using ADB
* COPY using POLYBASE
* Azure Batch job life cycle


## Steps:
1. Follow the instructions in each file.
