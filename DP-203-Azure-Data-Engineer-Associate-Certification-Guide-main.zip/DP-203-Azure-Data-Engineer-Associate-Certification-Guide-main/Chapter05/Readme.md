# Chapter 5

## Overview
In this chapter, we will see code examples for: 

* Compressing files using Spark
* Horizontal Partitioning using Synapse SQL
* Horizontal Partitioning or Sharding using Spark
* Implementing distributions using Synapse SQL


## Steps:
1. Follow the instructions in each file.







